# 0.8.0 - 2015-03-03

- Removed: bower support
- Removed: component(1) support
- Changed: Upgrade to color-string 0.3

---

Check out commit logs for older releases
