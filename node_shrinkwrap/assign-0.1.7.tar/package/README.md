# Assign

Assign in an experimental module that makes it easier to parse async data using
the tools we're already accustomed to in our development flows. You could see it
as an incremental asynchronous map/reduce promise.

## Installation

The module is released in the public npm registry.

```
npm install --save assign
```

## Usage

## License

MIT
